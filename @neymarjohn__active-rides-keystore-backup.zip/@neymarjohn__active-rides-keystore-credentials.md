# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 6627cf79a7204dae9a821a18a588ed8f
- Android key alias: QG5leW1hcmpvaG4vYWN0aXZlLXJpZGVz
- Android key password: 4ac25c5ff3b7411885f389b2fbb7005f
      